﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Long_Dark_Save_Editor_2.Game_data;
using The_Long_Dark_Save_Editor_2.Helpers;
using The_Long_Dark_Save_Editor_2.Serialization;

namespace The_Long_Dark_Save_Editor_2
{
    class Program
    {
        static int Main(string[] args)
        {
            FileInfo save = null;
            FileInfo save_out = null;

            if(args != null && args.Length != 0 && File.Exists(args[0])) 
            {
                save = new FileInfo(args[0]);
                save_out = new FileInfo(save.FullName + "_new");
            }
            //Debug
            //save = new FileInfo(@"D:\Win10\Desktop\临时文件\challenge16");
            //save_out = new FileInfo(@"D:\Win10\Desktop\临时文件\challenge16_new");
            //EndDebug

            if (save == null || save_out == null || !save.Exists) { Console.WriteLine("Invalid save file. press any key to exit."); Console.ReadKey(); return -1; }

            Console.WriteLine("Save path is : " + save.FullName);

            string slotJson_str = EncryptString.Decompress(File.ReadAllBytes(save.FullName));
            var slotJson = (JObject)JsonConvert.DeserializeObject(slotJson_str);

            var dict = slotJson["m_Dict"];

            Console.WriteLine();
            while (true)
            {
                Console.WriteLine("===== Loading all m_Dict =====");
                Console.WriteLine();

                var index_width = dict.Children().Count().ToString().Length;

                for (int i = 2; i < dict.Children().Count(); i++)
                {
                    var key = ((JProperty)dict.Children().ElementAt(i)).Name;
                    var format = " {0," + index_width + "}. {1" + "}";
                    Console.WriteLine(format, i - 1, key);
                }

                Console.WriteLine("\nChoose to delete using integer (write '0' to save)");

                var choice = Console.ReadLine();

                int choice_int = -1;
                var flag = int.TryParse(choice, out choice_int);

                choice_int++;

                if (choice_int == 1) { break; }

                if (!flag || choice_int < 1 || choice_int >= dict.Children().Count())
                {
                    Console.WriteLine("Invalid Choice\n"); continue;
                }

                var children = (JProperty)dict.Children().ElementAt(choice_int);
                var name = children.Name;
                children.Remove();

                Console.WriteLine("\n'" + name + "' Removed! Press any key to unpause");
                Console.ReadKey();
                Console.WriteLine();
            }

            Save(slotJson,save_out.FullName);

            Console.WriteLine("\n----- Done, press any key to exit -----");
            Console.ReadKey();
            return 0;
        }

        static void Save(JObject slotJson, string path)
        {
            Console.WriteLine("\nSaving file...");
            string slotJson_str = JsonConvert.SerializeObject(slotJson);
            var data = EncryptString.Compress(slotJson_str);
            File.WriteAllBytes(path, data);
            Console.WriteLine("\nSaved");
        }
    }
    class SlotData
    {
        public string m_Name { get; set; }
        public string m_BaseName { get; set; }
        public string m_DisplayName { get; set; }
        public string m_Timestamp { get; set; }
        public EnumWrapper<SaveSlotType> m_GameMode { get; set; }
        public uint m_GameId { get; set; }
        public Dictionary<string, byte[]> m_Dict { get; set; }
    }

    public enum SaveSlotType
    {
        UNKNOWN,
        CHALLENGE,
        CHECKPOINT,
        SANDBOX,
        STORY,
        AUTOSAVE,
    }
}
