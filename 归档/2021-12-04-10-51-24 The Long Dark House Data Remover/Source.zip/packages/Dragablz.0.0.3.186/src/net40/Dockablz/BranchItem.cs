﻿namespace Dragablz.Dockablz
{
    public enum BranchItem
    {
        First,
        Second
    }
}